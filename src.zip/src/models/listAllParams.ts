export interface SearchBy {
  author?: string,
}

export interface SearchTerm {
  term: string,
}