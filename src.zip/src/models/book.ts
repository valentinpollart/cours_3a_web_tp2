export interface Book {
    title: string;
    author: string;
    date: Date;
}