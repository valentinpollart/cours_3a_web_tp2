export class Pagination {
  perPage: number;
  page: number;
}

export class PaginatedResult {
  data: any
  page: number
  perPage: number
  totalCount: number
}



